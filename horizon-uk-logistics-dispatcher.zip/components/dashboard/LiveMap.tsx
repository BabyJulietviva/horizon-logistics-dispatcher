'use client';

import { useState, useEffect } from 'react';
import { Map as MapIcon, Navigation, Compass, Layers, Zap, Satellite, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function LiveMap() {
  const [optimizing, setOptimizing] = useState(false);
  const [driverPos, setDriverPos] = useState({ x: 50, y: 50 });
  const [driver2Pos, setDriver2Pos] = useState({ x: 33, y: 25 });

  // Simulate GPS movement
  useEffect(() => {
    const interval = setInterval(() => {
      setDriverPos(prev => ({
        x: prev.x + (Math.random() - 0.5) * 2,
        y: prev.y + (Math.random() - 0.5) * 2
      }));
      setDriver2Pos(prev => ({
        x: prev.x + (Math.random() - 0.5) * 1.5,
        y: prev.y + (Math.random() - 0.5) * 1.5
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const runOptimization = () => {
    setOptimizing(true);
    setTimeout(() => setOptimizing(false), 2000);
  };

  return (
    <div className="bg-primary-navy rounded-2xl border border-white/10 shadow-sm relative overflow-hidden h-full group">
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute inset-0" style={{ 
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '24px 24px'
        }} />
      </div>
      
      {/* Search Header */}
      <div className="absolute top-4 left-4 right-4 z-10 flex gap-2">
        <div className="flex-1 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-2 px-4 flex items-center gap-3">
          <MapIcon className="w-4 h-4 text-secondary-gold" />
          <input 
            type="text" 
            placeholder="Search UK Hubs / Fleet..." 
            className="bg-transparent border-none outline-none text-xs text-neutral-white w-full placeholder:text-neutral-mid"
          />
        </div>
        <button 
          onClick={runOptimization}
          disabled={optimizing}
          className="p-3 bg-secondary-gold rounded-xl hover:bg-white transition-all disabled:opacity-50 flex items-center gap-2 group/btn"
        >
          {optimizing ? (
            <Zap className="w-4 h-4 text-primary-navy animate-pulse" />
          ) : (
            <Satellite className="w-4 h-4 text-primary-navy" />
          )}
          <span className="hidden md:inline text-[10px] font-bold text-primary-navy uppercase tracking-wider">
            {optimizing ? 'Optimising...' : 'Auto-Route'}
          </span>
        </button>
      </div>

      {/* Map Content Placeholder */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative w-full h-full">
          {/* Simulated Routes */}
          <svg className="absolute inset-0 w-full h-full opacity-30 text-secondary-gold" viewBox="0 0 100 100" preserveAspectRatio="none">
            <motion.path 
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 5 }}
              d="M10,80 Q50,70 90,80" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="0.2" 
              strokeDasharray="2,2" 
            />
            <path d="M20,10 L50,50 L80,20" fill="none" stroke="currentColor" strokeWidth="0.2" strokeDasharray="2,2" />
          </svg>
          
          {/* Active Drivers (GPS Simulation) */}
          <motion.div 
            animate={{ left: `${driverPos.x}%`, top: `${driverPos.y}%` }}
            transition={{ duration: 3, ease: "linear" }}
            className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center"
          >
             <div className="w-4 h-4 bg-secondary-gold rounded-full animate-ping absolute" />
             <div className="w-4 h-4 bg-secondary-gold rounded-full relative shadow-[0_0_15px_rgba(200,155,60,0.5)] border-2 border-primary-navy" />
             <span className="text-[9px] text-neutral-white font-mono mt-1 bg-primary-navy/90 px-1 rounded uppercase whitespace-nowrap border border-white/10">King • G-HKY1</span>
          </motion.div>
          
           <motion.div 
            animate={{ left: `${driver2Pos.x}%`, top: `${driver2Pos.y}%` }}
            transition={{ duration: 3, ease: "linear" }}
            className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center"
          >
             <div className="w-4 h-4 bg-primary-blue rounded-full relative shadow-[0_0_15px_rgba(30,136,229,0.5)] border-2 border-primary-navy" />
             <span className="text-[9px] text-neutral-white font-mono mt-1 bg-primary-navy/90 px-1 rounded uppercase whitespace-nowrap border border-white/10">Chen • G-LK92</span>
          </motion.div>
        </div>
      </div>

      {/* Map Controls */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2">
        <button className="p-2 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 text-neutral-white hover:bg-white/20 transition-all">
          <Compass className="w-4 h-4" />
        </button>
        <button className="p-2 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 text-neutral-white hover:bg-white/20 transition-all">
          <Layers className="w-4 h-4" />
        </button>
      </div>

      <div className="absolute bottom-4 left-4 bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/20 min-w-[150px]">
        <h4 className="text-[10px] font-bold text-secondary-gold uppercase tracking-wider mb-2 flex items-center gap-2">
          <Activity className="w-3 h-3" /> Live GPS Feed
        </h4>
        <div className="space-y-2">
          <div className="flex justify-between items-center text-[10px] text-neutral-white font-mono">
            <span className="opacity-60">Fleet Active</span>
            <span className="text-status-success font-bold">12/14</span>
          </div>
          <div className="flex justify-between items-center text-[10px] text-neutral-white font-mono">
            <span className="opacity-60">Avg. Delay</span>
            <span className="text-status-warning font-bold">4.2m</span>
          </div>
        </div>
      </div>

      {/* Optimization Overlay */}
      <AnimatePresence>
        {optimizing && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-primary-navy/40 backdrop-blur-[2px] z-20 flex items-center justify-center p-8"
          >
            <div className="bg-neutral-white rounded-2xl p-6 shadow-2xl flex flex-col items-center text-center gap-4 max-w-xs">
              <div className="w-12 h-12 bg-secondary-gold/20 rounded-full flex items-center justify-center">
                <Zap className="w-6 h-6 text-secondary-gold animate-bounce" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-neutral-black uppercase tracking-tight">Recalculating Routes</h3>
                <p className="text-[10px] text-neutral-mid mt-1">Analyzing UK traffic patterns & fuel efficiency...</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
