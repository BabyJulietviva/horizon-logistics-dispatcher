'use client';

import { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Truck, 
  Map as MapIcon, 
  Settings, 
  LogOut,
  ChevronRight,
  Menu
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', id: 'dashboard', active: true },
  { icon: Package, label: 'Orders', id: 'orders' },
  { icon: Truck, label: 'Drivers', id: 'drivers' },
  { icon: MapIcon, label: 'Routes', id: 'routes' },
  { icon: Settings, label: 'Settings', id: 'settings' },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside className={cn(
      "bg-primary-navy min-h-screen flex flex-col border-r border-white/10 transition-all duration-300 ease-in-out relative z-30",
      collapsed ? "w-20" : "w-64"
    )}>
      <div className={cn("p-6 mb-4 flex items-center shrink-0", collapsed ? "justify-center" : "justify-between")}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-secondary-gold rounded-lg flex items-center justify-center shrink-0">
            <Truck className="w-5 h-5 text-primary-navy" />
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <h1 className="text-xl font-display font-bold text-neutral-white leading-tight">HORIZON</h1>
              <p className="text-secondary-gold/60 text-[8px] font-mono tracking-[0.2em] uppercase">UK Dispatch</p>
            </div>
          )}
        </div>
        
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className="p-1.5 hover:bg-white/10 rounded-lg text-neutral-mid hidden lg:block"
        >
          <Menu className={cn("w-4 h-4 transition-transform", !collapsed && "rotate-180")} />
        </button>
      </div>

      <nav className="flex-1 px-3 space-y-1.5">
        {navItems.map((item) => (
          <button
            key={item.id}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group relative truncate",
              item.active 
                ? "bg-primary-blue text-neutral-white shadow-lg shadow-primary-blue/20" 
                : "text-neutral-mid hover:text-neutral-white hover:bg-white/5"
            )}
          >
            <item.icon className={cn("w-5 h-5 shrink-0", item.active ? "text-neutral-white" : "group-hover:text-neutral-white")} />
            {!collapsed && (
              <>
                <span className="font-medium text-sm truncate">{item.label}</span>
                {item.active && (
                  <ChevronRight className="w-4 h-4 ml-auto opacity-40" />
                )}
              </>
            )}
          </button>
        ))}
      </nav>

      <div className="p-3 mt-auto mb-4 border-t border-white/5">
        <button className={cn(
          "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-status-error/80 hover:bg-status-error/10 transition-colors",
          collapsed && "justify-center"
        )}>
          <LogOut className="w-5 h-5 shrink-0" />
          {!collapsed && <span className="font-medium text-sm">Logout</span>}
        </button>
      </div>
    </aside>
  );
}
