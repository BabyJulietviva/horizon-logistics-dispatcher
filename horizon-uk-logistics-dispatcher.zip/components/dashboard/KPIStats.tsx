'use client';

import { TrendingUp, Users, Activity, Droplets } from 'lucide-react';
import { motion } from 'motion/react';
import { Area, AreaChart, ResponsiveContainer, YAxis } from 'recharts';

const data = [
  { value: 400 }, { value: 300 }, { value: 500 }, { value: 450 }, { value: 600 }, { value: 550 }, { value: 700 }
];

const stats = [
  { label: 'Fuel Saved Today', value: '£4,291', trend: '+2.1%', icon: Droplets, color: 'text-secondary-gold' },
  { label: 'On-Time (UK Wide)', value: '94.2%', trend: '+0.5%', icon: TrendingUp, color: 'text-status-success' },
  { label: 'HGV Utilisation', value: '82.5%', trend: '-1.2%', icon: Users, color: 'text-primary-blue' },
  { label: 'Active UK Drops', value: '1,428', trend: '+14%', icon: Activity, color: 'text-primary-navy' },
];

export function KPIStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="bg-neutral-white p-6 rounded-2xl border border-neutral-mid/10 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group"
        >
          <div className="flex justify-between items-start mb-4 relative z-10">
            <div className={cn("p-2 rounded-lg bg-neutral-light", stat.color)}>
              <stat.icon className="w-5 h-5" />
            </div>
            <span className={cn(
              "text-xs font-bold px-2 py-1 rounded-full",
              stat.trend.startsWith('+') ? "bg-status-success/10 text-status-success" : "bg-status-error/10 text-status-error"
            )}>
              {stat.trend}
            </span>
          </div>
          
          <div className="relative z-10">
            <h3 className="text-neutral-mid text-xs font-medium uppercase tracking-wider mb-1">{stat.label}</h3>
            <p className="text-2xl font-bold text-neutral-black tracking-tight">{stat.value}</p>
          </div>

          <div className="absolute inset-0 top-16 opacity-10 group-hover:opacity-20 transition-opacity">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <Area 
                  type="monotone" 
                  dataKey="value" 
                  stroke="currentColor" 
                  strokeWidth={2} 
                  fill="currentColor" 
                  className={stat.color.replace('text-', 'fill-').replace('text-', 'stroke-')}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

// Helper function locally if not available
function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}
