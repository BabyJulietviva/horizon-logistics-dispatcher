'use client';

import { useState } from 'react';
import { MoreVertical, MapPin, Clock, User as UserIcon, BadgeAlert } from 'lucide-react';
import { cn } from '@/lib/utils';

const initialOrders = [
  { id: 'GB-LX-8291', customer: 'London Distribution', status: 'In Transit', priority: 'Urgent', driver: 'Marcus King', destination: 'Southwark SE1', eta: '14:20' },
  { id: 'GB-MN-8292', customer: 'Manchester Freight', status: 'Pending', priority: 'High', driver: 'Unassigned', destination: 'Trafford M17', eta: '--' },
  { id: 'GB-BM-8293', customer: 'Birmingham Retail', status: 'Delivered', priority: 'Medium', driver: 'Sarah Chen', destination: 'City Centre B1', eta: 'Completed' },
  { id: 'GB-GL-8294', customer: 'Glasgow Express', status: 'In Transit', priority: 'Low', driver: 'Jack Wilson', destination: 'Hillhead G12', eta: '15:45' },
  { id: 'GB-LS-8295', customer: 'Leeds Logistics', status: 'Pending', priority: 'High', driver: 'Unassigned', destination: 'Hunslet LS10', eta: '--' },
];

export function OrdersTable() {
  const [filter, setFilter] = useState('all');

  return (
    <div className="bg-neutral-white rounded-2xl border border-neutral-mid/10 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="p-6 border-b border-neutral-mid/10 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-neutral-black">Active Delivery Orders</h2>
          <p className="text-xs text-neutral-mid">Managing 24 orders for today&apos;s shift</p>
        </div>
        <div className="flex gap-2">
          {['all', 'Pending', 'In Transit', 'Delivered'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f.toLowerCase())}
              className={cn(
                "px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
                (filter === f.toLowerCase()) 
                  ? "bg-primary-blue text-neutral-white" 
                  : "bg-neutral-light text-neutral-mid hover:bg-neutral-mid/10"
              )}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-neutral-light">
              <th className="px-6 py-4 text-xs font-bold text-neutral-mid uppercase tracking-wider">Order ID</th>
              <th className="px-6 py-4 text-xs font-bold text-neutral-mid uppercase tracking-wider">Customer</th>
              <th className="px-6 py-4 text-xs font-bold text-neutral-mid uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-xs font-bold text-neutral-mid uppercase tracking-wider">Driver</th>
              <th className="px-6 py-4 text-xs font-bold text-neutral-mid uppercase tracking-wider">Priority</th>
              <th className="px-6 py-4 text-xs font-bold text-neutral-mid uppercase tracking-wider text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-mid/5">
            {initialOrders.filter(o => filter === 'all' || o.status.toLowerCase() === filter).map((order) => (
              <tr key={order.id} className="hover:bg-primary-blue/5 transition-colors group">
                <td className="px-6 py-4 font-mono text-xs font-bold text-primary-blue">{order.id}</td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-neutral-black">{order.customer}</span>
                    <span className="text-[10px] text-neutral-mid flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {order.destination}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={cn(
                    "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                    order.status === 'In Transit' && "bg-status-info/10 text-status-info",
                    order.status === 'Pending' && "bg-status-warning/10 text-status-warning",
                    order.status === 'Delivered' && "bg-status-success/10 text-status-success",
                  )}>
                    {order.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-neutral-light flex items-center justify-center border border-neutral-mid/20">
                      <UserIcon className="w-3 h-3 text-neutral-mid" />
                    </div>
                    <span className="text-xs text-neutral-dark font-medium">{order.driver}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={cn(
                    "flex items-center gap-1 text-[10px] font-bold uppercase",
                    order.priority === 'Urgent' && "text-status-error",
                    order.priority === 'High' && "text-status-warning",
                    order.priority === 'Medium' && "text-primary-blue",
                    order.priority === 'Low' && "text-neutral-mid",
                  )}>
                    {order.priority === 'Urgent' && <BadgeAlert className="w-3 h-3" />}
                    {order.priority}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="p-1 hover:bg-neutral-mid/10 rounded-md transition-colors">
                    <MoreVertical className="w-4 h-4 text-neutral-mid" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="p-4 bg-neutral-light border-t border-neutral-mid/10 mt-auto">
        <button className="w-full py-2 text-xs font-bold text-primary-navy hover:text-primary-blue transition-colors flex items-center justify-center gap-2">
          View All Dispatch Records <Clock className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
