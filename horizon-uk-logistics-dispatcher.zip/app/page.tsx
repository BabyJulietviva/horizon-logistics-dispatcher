/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

'use client';

import { useState, useEffect } from 'react';
import { 
  Bell, 
  Search, 
  Plus, 
  Calendar,
  Grid,
  List as ListIcon,
  Filter,
  User,
  LogOut,
  MapPin,
  Clock,
  TrendingUp,
  Activity,
  Droplets,
  Users as UsersIcon,
  Truck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Sidebar } from '@/components/dashboard/Sidebar';
import { KPIStats } from '@/components/dashboard/KPIStats';
import { OrdersTable } from '@/components/dashboard/OrdersTable';
import { LiveMap } from '@/components/dashboard/LiveMap';
import { cn } from '@/lib/utils';

export default function DashboardPage() {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex h-screen bg-neutral-light overflow-hidden font-sans">
      <Sidebar />

      <main className="flex-1 flex flex-col min-w-0">
        {/* Top Navbar */}
        <header className="h-20 bg-neutral-white border-b border-neutral-mid/10 px-8 flex items-center justify-between shrink-0">
          <div className="flex flex-col">
            <h2 className="text-xl font-display font-bold text-neutral-black tracking-tight">Main Dispatch Deck</h2>
            <p className="text-xs text-neutral-mid flex items-center gap-1.5 font-medium" suppressHydrationWarning>
              <Calendar className="w-3.5 h-3.5" /> 
              {currentTime.toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden lg:flex items-center gap-3 bg-neutral-light/50 border border-neutral-mid/10 px-4 py-2 rounded-xl focus-within:bg-white focus-within:border-primary-blue transition-all w-64">
              <Search className="w-4 h-4 text-neutral-mid" />
              <input 
                type="text" 
                placeholder="Search UK Fleet / Orders..." 
                className="bg-transparent border-none outline-none text-sm text-neutral-black placeholder:text-neutral-mid w-full"
              />
            </div>

            <div className="flex items-center gap-3">
              <button className="relative p-2 text-neutral-mid hover:text-primary-blue hover:bg-neutral-light rounded-xl transition-all">
                <Bell className="w-5 h-5" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-status-error border-2 border-neutral-white rounded-full"></span>
              </button>
              
              <div className="w-px h-6 bg-neutral-mid/20 mx-1"></div>

              <div className="flex items-center gap-3 pl-1">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-bold text-neutral-black leading-none">Duty Dispatcher</p>
                  <p className="text-[10px] text-primary-blue font-bold uppercase tracking-wider mt-0.5">UK Logistics Hub</p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-primary-navy flex items-center justify-center border-2 border-primary-blue/20">
                  <span className="text-secondary-gold font-bold">HQ</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          {/* Quick Actions & Breadcrumbs */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-neutral-mid">
              <span>Operations</span>
              <span className="text-[10px] opacity-30">/</span>
              <span className="text-primary-blue">Dispatcher Dashboard</span>
            </div>
            <button className="bg-secondary-gold hover:bg-neutral-black text-neutral-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-secondary-gold/20 flex items-center gap-2 transition-all group">
              <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" />
              Create Delivery Batch
            </button>
          </div>

          {/* KPI Dashboard */}
          <KPIStats />

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 pb-8">
            {/* Orders Table - Spans 2 columns on XL */}
            <div className="xl:col-span-2">
              <OrdersTable />
            </div>

            {/* Map & Right Column Panel */}
            <div className="space-y-8 flex flex-col min-h-[600px] xl:min-h-0">
               <div className="flex-1 min-h-[400px]">
                 <LiveMap />
               </div>

               {/* Notifications / Alerts Panel */}
               <div className="bg-neutral-white p-6 rounded-2xl border border-neutral-mid/10 shadow-sm shrink-0">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-bold text-neutral-black flex items-center gap-2">
                      <Activity className="w-4 h-4 text-status-warning" />
                      Dispatch Alerts
                    </h3>
                  </div>
                  <div className="space-y-3">
                    <div className="p-3 bg-status-error/5 border-l-4 border-status-error rounded-r-lg">
                      <p className="text-xs font-bold text-status-error">Heavy Traffic Ahead</p>
                      <p className="text-[10px] text-neutral-dark mt-0.5">Route B-42 delayed by 15 mins due to construction on Highway 10.</p>
                    </div>
                    <div className="p-3 bg-primary-blue/5 border-l-4 border-primary-blue rounded-r-lg">
                      <p className="text-xs font-bold text-primary-blue">New Driver Approved</p>
                      <p className="text-[10px] text-neutral-dark mt-0.5">Marcus King is now active and available for route assignment.</p>
                    </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
